# BUSI Ultrasound Image Segmentation

This repository contains Jupyter notebooks for breast ultrasound image segmentation using the BUSI dataset (`Dataset_BUSI_with_GT`). The workflow includes dataset inspection, image-mask pairing, stratified 5-fold metadata preparation, augmentation, train/validation splitting, and 5-fold segmentation model training.

## Files

- `Another_copy_of_segmention.ipynb` — prepares the BUSI image-mask metadata and creates stratified 5-fold splits.
- `5cv-fold.ipynb` — includes Kaggle dataset loading, augmentation, train/validation split creation, model setup, and 5-fold cross-validation training.
- `requirements.txt` — Python packages needed to run the notebooks.
- `.gitignore` — ignores datasets, model checkpoints, cache files, and generated outputs.

## Dataset

The notebooks are written for the BUSI ultrasound dataset with this folder structure:

```text
Dataset_BUSI_with_GT/
├── benign/
├── malignant/
└── normal/
```

The dataset itself is not included in this repository because datasets are usually too large for GitHub. Place the dataset locally, in Google Drive, or in Kaggle input storage, then update the dataset paths inside the notebooks if needed.

## How to run

1. Create a Python environment.
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Open the notebooks in Jupyter, Google Colab, or Kaggle.
4. Run `Another_copy_of_segmention.ipynb` first if you need to generate `busi_metadata_5fold.csv`.
5. Run `5cv-fold.ipynb` for augmentation, dataset split, model creation, and 5-fold training.

## Notes

- The notebooks currently contain paths for Google Colab and Kaggle. Change the paths according to your environment.
- Keep dataset folders, trained model checkpoints, and generated outputs out of GitHub unless they are small and necessary.
- For journal or publication work, report fold-wise metrics and mean ± standard deviation across the 5 folds.
