# GitHub Upload Instructions

Option 1 — Upload through GitHub website:
1. Download and extract this ZIP file.
2. Create a new GitHub repository.
3. Open the extracted folder.
4. Upload all files from inside the folder to GitHub.
5. Commit the files.

Option 2 — Upload using Git commands:

```bash
git init
git add .
git commit -m "Initial commit: BUSI segmentation notebooks"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPOSITORY.git
git push -u origin main
```

Replace `YOUR_USERNAME` and `YOUR_REPOSITORY` with your GitHub username and repository name.
